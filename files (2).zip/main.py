"""
DrawScript — WHITE CANVAS EDITION
Now with Multi-Select & Alignment Tools (v1.2)!

Entry point.  Imports from:
  styles  → DARK_QSS
  items   → StyledRectItem, DraggableTextItem, DraggableImageItem
  widgets → DarkCanvasView, PropertyInspector, _h_rule
"""

import sys
import json
import random
import pathlib

from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QHBoxLayout, QVBoxLayout,
    QPushButton, QGraphicsView, QLabel, QTextEdit,
    QTabWidget, QTextBrowser, QFileDialog, QStatusBar, QFont,
)
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QKeySequence, QShortcut, QColor, QPixmap

from styles import DARK_QSS
from items import StyledRectItem, DraggableTextItem, DraggableImageItem
from widgets import DarkCanvasView, PropertyInspector, _h_rule


# ---------------------------------------------------------------------------
# Keyboard-shortcuts mixin
# ---------------------------------------------------------------------------

class KeyboardShortcutsMixin:
    def setup_keyboard_shortcuts(self):
        self._clipboard_shape_data = None
        self._undo_stack = []

        self._witty_prefixes = [
            ">> ", "[SYS] ", "[OK]  ", "[INF] ", "[MSG] ", "*** ",
        ]

        QShortcut(QKeySequence("Ctrl+C"),    self).activated.connect(self._copy_shape)
        QShortcut(QKeySequence("Ctrl+V"),    self).activated.connect(self._paste_shape)
        QShortcut(QKeySequence("Delete"),    self).activated.connect(self._delete_selected)
        QShortcut(QKeySequence("Backspace"), self).activated.connect(self._delete_selected)
        QShortcut(QKeySequence("Ctrl+Z"),    self).activated.connect(self._undo_delete)
        QShortcut(QKeySequence("Ctrl+E"),    self).activated.connect(self._on_generate)

        if self.statusBar() is None:
            self.setStatusBar(QStatusBar())

        self._show_witty("KEYBOARD INTERFACE ONLINE. CTRL+C/V/Z/E/DEL")

    def _copy_shape(self):
        selected = self.canvas.scene.selectedItems()
        if not selected:
            return
        item = selected[0]
        if isinstance(item, StyledRectItem):
            self._clipboard_shape_data = {
                "type":  "rect",
                "w":      item.rect().width(), "h": item.rect().height(),
                "fill":   item.fill_color(), "rad": item.border_radius(),
                "src_x":  item.x(), "src_y": item.y(),
            }
        elif isinstance(item, DraggableTextItem):
            self._clipboard_shape_data = {
                "type":   "text",
                "text":   item.toPlainText(), "color": item.text_color(),
                "size":   item.font_size(), "weight": item.thickness(),
                "src_x":  item.x(), "src_y": item.y(),
            }
        elif isinstance(item, DraggableImageItem):
            self._clipboard_shape_data = {
                "type":  "image",
                "path":  item.file_path(),
                "w":     item.img_width(), "h": item.img_height(),
                "src_x": item.x(), "src_y": item.y(),
            }
        else:
            return
        self._show_witty("BLOCK COPIED TO BUFFER.")

    def _paste_shape(self):
        if not self._clipboard_shape_data:
            self._show_witty("BUFFER IS EMPTY.")
            return
        data   = self._clipboard_shape_data
        offset = 24
        ox, oy = data["src_x"] + offset, data["src_y"] + offset
        if data["type"] == "rect":
            new_item = StyledRectItem(ox, oy, data["w"], data["h"])
            new_item.set_fill_color(data["fill"])
            new_item.set_border_radius(data["rad"])
        elif data["type"] == "text":
            new_item = DraggableTextItem(data["text"], ox, oy)
            new_item.set_text_color(data["color"])
            new_item.set_font_size(data["size"])
            new_item.set_thickness(data["weight"])
        elif data["type"] == "image":
            new_item = DraggableImageItem(data["path"], ox, oy, data["w"], data["h"])
        else:
            return
        self.canvas.scene.addItem(new_item)
        self._show_witty("BLOCK PASTED FROM BUFFER.")

    def _delete_selected(self):
        selected = self.canvas.scene.selectedItems()
        if not selected:
            return
        self._undo_stack.append(list(selected))
        for item in selected:
            self.canvas.scene.removeItem(item)
        count = len(selected)
        self._show_witty(f"{count} {'BLOCK' if count == 1 else 'BLOCKS'} DELETED. CTRL+Z TO RESTORE.")

    def _undo_delete(self):
        if not self._undo_stack:
            self._show_witty("NOTHING TO UNDO.")
            return
        items = self._undo_stack.pop()
        for item in items:
            self.canvas.scene.addItem(item)
        self._show_witty(f"RESTORED {len(items)} BLOCK(S).")

    def _show_witty(self, message: str):
        prefix = random.choice(self._witty_prefixes)
        self.statusBar().showMessage(prefix + message, 3500)


# ---------------------------------------------------------------------------
# Main window
# ---------------------------------------------------------------------------

class DarkMainWindow(QMainWindow, KeyboardShortcutsMixin):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("DRAWSCRIPT // WHITE CANVAS EDITION")
        self.resize(1360, 760)
        self.setStatusBar(QStatusBar())

        toolbar_widget = self._build_toolbar()
        self.canvas    = DarkCanvasView()
        right_panel    = self._build_right_panel()

        central     = QWidget()
        main_layout = QHBoxLayout(central)
        main_layout.setSpacing(0)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.addWidget(toolbar_widget)
        main_layout.addWidget(self.canvas)
        main_layout.addWidget(right_panel)
        self.setCentralWidget(central)

        self._wire_signals()
        self.setup_keyboard_shortcuts()

    # ------------------------------------------------------------------
    # Layout builders
    # ------------------------------------------------------------------

    def _build_toolbar(self) -> QWidget:
        widget = QWidget()
        widget.setObjectName("Toolbar")
        widget.setFixedWidth(148)

        layout = QVBoxLayout(widget)
        layout.setAlignment(Qt.AlignmentFlag.AlignTop)
        layout.setSpacing(6)
        layout.setContentsMargins(10, 14, 10, 14)

        section_lbl = QLabel("[ CANVAS ]")
        section_lbl.setObjectName("heading")
        layout.addWidget(section_lbl)
        layout.addWidget(_h_rule())
        layout.addSpacing(4)

        self.btn_box = QPushButton("[+] ADD BOX")
        self.btn_txt = QPushButton("[A] ADD TEXT")
        self.btn_img = QPushButton("[+] ADD IMAGE")
        self.btn_clr = QPushButton("[X] CLEAR")
        self.btn_gen = QPushButton("[/] GENERATE")
        self.btn_exp = QPushButton("[S] EXPORT")

        self.btn_img.setObjectName("btn_img")
        self.btn_clr.setObjectName("btn_clear")
        self.btn_gen.setObjectName("btn_generate")

        for btn in (self.btn_box, self.btn_txt, self.btn_img,
                    self.btn_clr, self.btn_gen, self.btn_exp):
            btn.setCursor(Qt.CursorShape.PointingHandCursor)
            layout.addWidget(btn)

        layout.addSpacing(10)
        persist_lbl = QLabel("[ PROJECT ]")
        persist_lbl.setObjectName("heading")
        layout.addWidget(persist_lbl)
        layout.addWidget(_h_rule())
        layout.addSpacing(4)

        self.btn_save = QPushButton("[↓] SAVE PROJECT")
        self.btn_open = QPushButton("[↑] OPEN PROJECT")
        self.btn_save.setObjectName("btn_save")
        self.btn_open.setObjectName("btn_open")

        for btn in (self.btn_save, self.btn_open):
            btn.setCursor(Qt.CursorShape.PointingHandCursor)
            layout.addWidget(btn)

        layout.addStretch()
        return widget

    def _build_right_panel(self) -> QWidget:
        panel = QWidget()
        panel.setObjectName("RightPanel")
        panel.setFixedWidth(350)

        layout = QVBoxLayout(panel)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        self.inspector = PropertyInspector()
        self.inspector.setFixedHeight(430)
        layout.addWidget(self.inspector)
        layout.addWidget(_h_rule())

        self.tabs            = QTabWidget()
        self.code_editor     = QTextEdit()
        self.preview_browser = QTextBrowser()

        retro_font = QFont("Consolas", 10)
        retro_font.setStyleHint(QFont.StyleHint.TypeWriter)
        retro_font.setBold(True)
        self.code_editor.setFont(retro_font)
        self.preview_browser.setFont(retro_font)

        self.tabs.addTab(self.code_editor,     "RAW CODE")
        self.tabs.addTab(self.preview_browser, "LIVE RENDER")
        layout.addWidget(self.tabs, stretch=1)
        return panel

    def _wire_signals(self):
        self.btn_box .clicked.connect(self.canvas.add_box)
        self.btn_txt .clicked.connect(self.canvas.add_text)
        self.btn_img .clicked.connect(self._on_add_image)
        self.btn_clr .clicked.connect(self._on_clear)
        self.btn_gen .clicked.connect(self._on_generate)
        self.btn_exp .clicked.connect(self._export_html)
        self.btn_save.clicked.connect(self._save_project)
        self.btn_open.clicked.connect(self._open_project)
        self.canvas.scene.selectionChanged.connect(self._on_selection)
        self.inspector.status_callback = self._show_witty

    # ------------------------------------------------------------------
    # Action handlers
    # ------------------------------------------------------------------

    def _on_add_image(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "OPEN IMAGE FILE", "",
            "Image Files (*.png *.jpg *.jpeg);;All Files (*)",
        )
        if not path:
            return
        probe = QPixmap(path)
        if probe.isNull():
            self._show_witty("IMAGE LOAD FAILED. UNSUPPORTED FORMAT OR CORRUPT FILE.")
            return
        self.canvas.add_image(path)
        self._show_witty(f"IMAGE ASSET LOADED. SOURCE: {probe.width()}x{probe.height()}px.")

    def _on_clear(self):
        self.canvas.clear_canvas()
        self.inspector.clear()
        self.code_editor.clear()
        self.preview_browser.clear()
        self._show_witty("CANVAS CLEARED. MEMORY WIPED.")

    def _on_selection(self):
        selected = self.canvas.scene.selectedItems()
        if len(selected) == 1 and isinstance(
            selected[0], (StyledRectItem, DraggableTextItem, DraggableImageItem)
        ):
            self.inspector.load_item(selected[0], self.canvas.scene)
        elif len(selected) >= 2:
            self.inspector.load_multi_select(selected, self.canvas.scene)
            self._show_witty(f"{len(selected)} BLOCKS IN SELECTION. ALIGNMENT MODE ACTIVE.")
        else:
            self.inspector.clear()

    def _on_generate(self):
        items = self.canvas.scene.items()
        if not items:
            self._show_witty("CANVAS EMPTY. ADD BLOCKS FIRST.")
            return

        html_map = {
            StyledRectItem: lambda it: {
                "type": "rect",
                "x": it.x(), "y": it.y(),
                "w": it.rect().width(), "h": it.rect().height(),
                "fill": it.fill_color().name(),
                "rad":  it.border_radius(),
                "z":    int(it.zValue()),
            },
            DraggableTextItem: lambda it: {
                "type":   "text",
                "x":      it.x(), "y": it.y(),
                "text":   it.toPlainText(),
                "color":  it.text_color().name(),
                "size":   it.font_size(),
                "weight": it.thickness_css(),
                "z":      int(it.zValue()),
            },
            DraggableImageItem: lambda it: {
                "type": "image",
                "x":    it.x(), "y": it.y(),
                "w":    it.img_width(), "h": it.img_height(),
                "path": it.file_path(),
                "z":    int(it.zValue()),
            },
        }
        shapes = sorted(
            [html_map[type(it)](it) for it in items if type(it) in html_map],
            key=lambda s: s["z"],
        )

        css = [
            "body { margin: 0; padding: 0; background-color: #ffffff; }",
            (
                ".drawscript-canvas { position: relative; width: 100vw; height: 100vh;"
                " overflow: hidden;"
                " font-family: 'Courier New', 'Consolas', monospace; }"
            ),
            ".canvas-item { position: absolute; }",
        ]
        html = ['<div class="drawscript-canvas">']

        for idx, shape in enumerate(shapes):
            item_id = f"item-{idx}"
            if shape["type"] == "text":
                html.append(
                    f'  <div id="{item_id}" class="canvas-item">{shape["text"]}</div>'
                )
                css.append(
                    f"#{item_id} {{"
                    f" left: {shape['x']:.0f}px; top: {shape['y']:.0f}px;"
                    f" font-size: {shape['size']}pt; font-weight: {shape['weight']};"
                    f" color: {shape['color']}; white-space: nowrap; z-index: {shape['z']};"
                    f"}}"
                )
            elif shape["type"] == "rect":
                html.append(f'  <div id="{item_id}" class="canvas-item"></div>')
                css.append(
                    f"#{item_id} {{"
                    f" left: {shape['x']:.0f}px; top: {shape['y']:.0f}px;"
                    f" width: {shape['w']:.0f}px; height: {shape['h']:.0f}px;"
                    f" background-color: {shape['fill']};"
                    f" border-radius: {shape['rad']:.0f}px;"
                    f" border: 2px solid #000000; z-index: {shape['z']};"
                    f"}}"
                )
            elif shape["type"] == "image":
                abs_uri = pathlib.Path(shape["path"]).as_uri()
                html.append(
                    f'  <img id="{item_id}" class="canvas-item" src="{abs_uri}" alt="">'
                )
                css.append(
                    f"#{item_id} {{"
                    f" left: {shape['x']:.0f}px; top: {shape['y']:.0f}px;"
                    f" width: {shape['w']:.0f}px; height: {shape['h']:.0f}px;"
                    f" display: block; z-index: {shape['z']};"
                    f"}}"
                )

        html.append("</div>")
        final_html = (
            "<!DOCTYPE html>\n<html>\n<head>\n"
            f"<style>\n{chr(10).join(css)}\n</style>\n"
            f"</head>\n<body>\n{chr(10).join(html)}\n</body>\n</html>"
        )

        self.code_editor.setPlainText(final_html)
        self.preview_browser.setHtml(final_html)
        self._show_witty(f"COMPILED {len(shapes)} BLOCK(S). OUTPUT READY.")

    # ------------------------------------------------------------------
    # Save / Load
    # ------------------------------------------------------------------

    def _save_project(self):
        items = self.canvas.scene.items()
        if not items:
            self._show_witty("NOTHING TO SAVE. CANVAS IS EMPTY.")
            return

        path, _ = QFileDialog.getSaveFileName(
            self, "SAVE PROJECT", "project.draw",
            "DrawScript Project (*.draw);;All Files (*)"
        )
        if not path:
            return

        save_map = {
            StyledRectItem: lambda it: {
                "type":   "rect",
                "x":      it.x(), "y": it.y(),
                "w":      it.rect().width(), "h": it.rect().height(),
                "fill":   it.fill_color().name(QColor.NameFormat.HexArgb),
                "radius": it.border_radius(), "z": it.zValue(),
            },
            DraggableTextItem: lambda it: {
                "type":   "text",
                "x":      it.x(), "y": it.y(),
                "text":   it.toPlainText(),
                "color":  it.text_color().name(QColor.NameFormat.HexArgb),
                "size":   it.font_size(), "weight": it.thickness(), "z": it.zValue(),
            },
            DraggableImageItem: lambda it: {
                "type": "image",
                "x":    it.x(), "y": it.y(),
                "w":    it.img_width(), "h": it.img_height(),
                "path": it.file_path(), "z": it.zValue(),
            },
        }
        payload = [save_map[type(it)](it) for it in items if type(it) in save_map]

        try:
            with open(path, "w", encoding="utf-8") as fh:
                json.dump({"version": 2, "items": payload}, fh, indent=2)
            self._show_witty(f"PROJECT ARCHIVED TO DISK. {len(payload)} BLOCK(S) COMMITTED.")
        except OSError as exc:
            self._show_witty(f"WRITE FAILED: {exc}")

    def _load_item_entry(self, entry: dict):
        kind = entry.get("type")
        if kind == "rect":
            item = StyledRectItem(entry["x"], entry["y"], entry["w"], entry["h"])
            c = QColor(entry["fill"])
            if c.isValid():
                item.set_fill_color(c)
            item.set_border_radius(entry.get("radius", 0))
            self.canvas._box_counter += 1
        elif kind == "text":
            item = DraggableTextItem(entry["text"], entry["x"], entry["y"])
            c = QColor(entry["color"])
            if c.isValid():
                item.set_text_color(c)
            item.set_font_size(entry.get("size", 14))
            item.set_thickness(entry.get("weight", 7))
            self.canvas._text_counter += 1
        elif kind == "image":
            item = DraggableImageItem(
                entry.get("path", ""), entry["x"], entry["y"],
                entry.get("w", 192), entry.get("h", 144),
            )
            self.canvas._image_counter += 1
        else:
            return None
        item.setZValue(entry.get("z", 0))
        return item

    def _open_project(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "OPEN PROJECT", "",
            "DrawScript Project (*.draw);;All Files (*)"
        )
        if not path:
            return

        try:
            with open(path, "r", encoding="utf-8") as fh:
                data = json.load(fh)
        except (OSError, json.JSONDecodeError) as exc:
            self._show_witty(f"PARSE ERROR: {exc}")
            return

        self.canvas.clear_canvas()
        self.inspector.clear()
        self.code_editor.clear()
        self.preview_browser.clear()

        items_data = data.get("items", [])
        for entry in items_data:
            item = self._load_item_entry(entry)
            if item:
                self.canvas.scene.addItem(item)

        self.canvas._z_counter = int(max((e.get("z", 0) for e in items_data), default=0)) + 1
        self._show_witty(f"DESIGN LOADED FROM ARCHIVE. {len(items_data)} BLOCK(S) RESTORED.")

    # ------------------------------------------------------------------
    # HTML export
    # ------------------------------------------------------------------

    def _export_html(self):
        content = self.code_editor.toPlainText().strip()
        if not content:
            self._show_witty("NO OUTPUT TO EXPORT. RUN GENERATE FIRST.")
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "EXPORT HTML", "index.html", "HTML Files (*.html)"
        )
        if path:
            with open(path, "w", encoding="utf-8") as fh:
                fh.write(content)
            self._show_witty(f"FILE WRITTEN TO DISK: {path}")


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main():
    app = QApplication(sys.argv)
    app.setStyleSheet(DARK_QSS)
    window = DarkMainWindow()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
