"""
DrawScript — items.py
Canvas item classes: CanvasItemMixin, StyledRectItem,
DraggableTextItem, and DraggableImageItem.
Also exports the module-level _snap() helper used by widgets.
"""

from PyQt6.QtWidgets import QGraphicsRectItem, QGraphicsTextItem, QGraphicsPixmapItem
from PyQt6.QtCore import Qt, QRectF, QPointF
from PyQt6.QtGui import (
    QPen, QBrush, QColor, QFont, QPainter, QPainterPath,
    QTextCursor, QTextCharFormat, QPixmap,
)
from PyQt6.QtWidgets import QStyle

from styles import GRID_STEP


# ---------------------------------------------------------------------------
# Grid-snap helper
# ---------------------------------------------------------------------------

def _snap(v: float) -> float:
    """Round *v* to the nearest GRID_STEP (24 px) boundary."""
    return round(v / GRID_STEP) * GRID_STEP


# ---------------------------------------------------------------------------
# Shared mixin for resizable canvas items
# ---------------------------------------------------------------------------

class CanvasItemMixin:
    """Shared constants, grid-snap helper, resize-handle paint, and
    press/release event pattern for StyledRectItem and DraggableImageItem."""

    HANDLE_SIZE = 12
    ACCENT      = QColor("#00E5FF")
    HANDLE_CLR  = QColor("#FFD166")

    def _snap(self, v: float) -> float:
        return _snap(v)

    def _paint_handle(self, painter, is_selected: bool):
        painter.setPen(Qt.PenStyle.NoPen)
        painter.fillRect(self._handle_rect(), self.HANDLE_CLR if is_selected else QColor("#111827"))

    def _capture_resize_origin(self):
        """Subclass stores its starting geometry (rect or w/h tuple) here."""

    def mousePressEvent(self, event):
        if (event.button() == Qt.MouseButton.LeftButton
                and self._handle_rect().contains(event.pos())):
            self._resizing         = True
            self._resize_start_pos = event.scenePos()
            self._capture_resize_origin()
            event.accept()
        else:
            self._resizing = False
            super().mousePressEvent(event)

    def mouseReleaseEvent(self, event):
        self._resizing = False
        super().mouseReleaseEvent(event)


# ---------------------------------------------------------------------------
# StyledRectItem
# ---------------------------------------------------------------------------

class StyledRectItem(CanvasItemMixin, QGraphicsRectItem):
    def __init__(self, x: float, y: float, w: float = 180, h: float = 90):
        super().__init__(0, 0, w, h)
        self.setPos(x, y)
        self.setFlags(
            QGraphicsRectItem.GraphicsItemFlag.ItemIsMovable    |
            QGraphicsRectItem.GraphicsItemFlag.ItemIsSelectable |
            QGraphicsRectItem.GraphicsItemFlag.ItemSendsGeometryChanges,
        )
        self._fill_color    = QColor("#1E2A3A")
        self._border_color  = QColor("#000000")
        self._border_radius = 0.0
        self._resizing          = False
        self._resize_start_pos  = None
        self._resize_start_rect = None

    def set_fill_color(self, color: QColor):
        self._fill_color = color
        self.update()

    def set_border_radius(self, radius: float):
        self._border_radius = float(radius)
        self.update()

    def fill_color(self) -> QColor:
        return QColor(self._fill_color)

    def border_radius(self) -> float:
        return self._border_radius

    def _handle_rect(self) -> QRectF:
        r = self.rect()
        s = self.HANDLE_SIZE
        return QRectF(r.right() - s, r.bottom() - s, s, s)

    def _capture_resize_origin(self):
        self._resize_start_rect = QRectF(self.rect())

    def paint(self, painter, option, widget=None):
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, False)
        is_selected = bool(option.state & QStyle.StateFlag.State_Selected)

        body = QPainterPath()
        body.addRoundedRect(self.rect(), self._border_radius, self._border_radius)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.fillPath(body, self._fill_color)

        border_pen = QPen(self.ACCENT if is_selected else self._border_color, 2.0)
        border_pen.setJoinStyle(Qt.PenJoinStyle.MiterJoin)
        painter.setPen(border_pen)
        painter.drawPath(body)

        if is_selected:
            glow_path = QPainterPath()
            glow_path.addRect(self.rect().adjusted(-3, -3, 3, 3))
            painter.setPen(QPen(QColor(0, 229, 255, 100), 2))
            painter.drawPath(glow_path)

        self._paint_handle(painter, is_selected)

    def mouseMoveEvent(self, event):
        if self._resizing:
            delta = event.scenePos() - self._resize_start_pos
            new_w = max(50, self._resize_start_rect.width()  + delta.x())
            new_h = max(24, self._resize_start_rect.height() + delta.y())
            self.setRect(0, 0, new_w, new_h)
            event.accept()
        else:
            super().mouseMoveEvent(event)


# ---------------------------------------------------------------------------
# DraggableTextItem
# ---------------------------------------------------------------------------

class DraggableTextItem(QGraphicsTextItem):
    """
    A movable, selectable, double-click-editable text item.
    Three independently controllable style axes:
      - color  — any QColor via set_text_color()
      - size   — point size 6–96 via set_font_size()
      - weight — nine levels (Thin->Black) via set_thickness()
    """

    WEIGHT_CSS = {
        1: 100, 2: 200, 3: 300, 4: 400, 5: 500,
        6: 600, 7: 700, 8: 800, 9: 900,
    }
    _WEIGHT_QFONT = {
        1: QFont.Weight.Thin,      2: QFont.Weight.ExtraLight,
        3: QFont.Weight.Light,     4: QFont.Weight.Normal,
        5: QFont.Weight.Medium,    6: QFont.Weight.DemiBold,
        7: QFont.Weight.Bold,      8: QFont.Weight.ExtraBold,
        9: QFont.Weight.Black,
    }

    def __init__(self, text: str, x: float, y: float):
        super().__init__(text)
        self.setPos(x, y)
        self._text_color = QColor("#0A0E17")
        self._font_size  = 14
        self._weight_val = 7
        self.setFlags(
            QGraphicsTextItem.GraphicsItemFlag.ItemIsMovable    |
            QGraphicsTextItem.GraphicsItemFlag.ItemIsSelectable |
            QGraphicsTextItem.GraphicsItemFlag.ItemSendsGeometryChanges,
        )
        self.setTextInteractionFlags(Qt.TextInteractionFlag.NoTextInteraction)
        self._apply_formatting()

    def _build_font(self) -> QFont:
        font = QFont("Courier New", self._font_size)
        font.setWeight(self._WEIGHT_QFONT.get(self._weight_val, QFont.Weight.Bold))
        return font

    def _apply_formatting(self):
        font = self._build_font()
        self.setFont(font)
        self.setDefaultTextColor(self._text_color)
        char_fmt = QTextCharFormat()
        char_fmt.setForeground(QBrush(self._text_color))
        char_fmt.setFont(font)
        cursor = self.textCursor()
        cursor.select(QTextCursor.SelectionType.Document)
        cursor.setCharFormat(char_fmt)
        cursor.clearSelection()
        self.setTextCursor(cursor)
        self.update()

    def set_text_color(self, color: QColor):
        self._text_color = QColor(color)
        self._apply_formatting()

    def text_color(self) -> QColor:
        return QColor(self._text_color)

    def set_font_size(self, size: int):
        self._font_size = max(6, min(size, 96))
        self._apply_formatting()

    def font_size(self) -> int:
        return self._font_size

    def set_thickness(self, weight_level: int):
        self._weight_val = max(1, min(weight_level, 9))
        self._apply_formatting()

    def thickness(self) -> int:
        return self._weight_val

    def thickness_css(self) -> int:
        return self.WEIGHT_CSS.get(self._weight_val, 700)

    def mouseDoubleClickEvent(self, event):
        self.setTextInteractionFlags(Qt.TextInteractionFlag.TextEditorInteraction)
        self.setFocus()
        super().mouseDoubleClickEvent(event)

    def focusOutEvent(self, event):
        self.setTextInteractionFlags(Qt.TextInteractionFlag.NoTextInteraction)
        self._apply_formatting()
        super().focusOutEvent(event)


# ---------------------------------------------------------------------------
# DraggableImageItem
# ---------------------------------------------------------------------------

class DraggableImageItem(CanvasItemMixin, QGraphicsPixmapItem):
    """
    A movable, resizable image item that renders a local image file on the canvas.
    Bottom-right resize handle, 24-px grid snapping on move, cyan selection border.
    """

    def __init__(self, file_path: str, x: float, y: float,
                 w: float = 192, h: float = 144):
        super().__init__()
        self._file_path = file_path
        self._img_w     = float(w)
        self._img_h     = float(h)

        self._source_pixmap = QPixmap(file_path)
        if self._source_pixmap.isNull():
            self._source_pixmap = QPixmap(int(w), int(h))
            self._source_pixmap.fill(QColor("#2A3A4A"))

        self._apply_scaled_pixmap()
        self.setPos(x, y)
        self.setFlags(
            QGraphicsPixmapItem.GraphicsItemFlag.ItemIsMovable    |
            QGraphicsPixmapItem.GraphicsItemFlag.ItemIsSelectable |
            QGraphicsPixmapItem.GraphicsItemFlag.ItemSendsGeometryChanges,
        )
        self._resizing          = False
        self._resize_start_pos  = None
        self._resize_start_size = (w, h)

    def file_path(self) -> str:
        return self._file_path

    def img_width(self) -> float:
        return self._img_w

    def img_height(self) -> float:
        return self._img_h

    def _apply_scaled_pixmap(self):
        scaled = self._source_pixmap.scaled(
            int(self._img_w), int(self._img_h),
            Qt.AspectRatioMode.IgnoreAspectRatio,
            Qt.TransformationMode.SmoothTransformation,
        )
        self.setPixmap(scaled)

    def _handle_rect(self) -> QRectF:
        s = self.HANDLE_SIZE
        return QRectF(self._img_w - s, self._img_h - s, s, s)

    def _capture_resize_origin(self):
        self._resize_start_size = (self._img_w, self._img_h)

    def boundingRect(self) -> QRectF:
        return QRectF(0, 0, self._img_w, self._img_h)

    def itemChange(self, change, value):
        if change == QGraphicsPixmapItem.GraphicsItemChange.ItemPositionChange:
            return QPointF(self._snap(value.x()), self._snap(value.y()))
        return super().itemChange(change, value)

    def paint(self, painter, option, widget=None):
        painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
        painter.drawPixmap(0, 0, int(self._img_w), int(self._img_h), self.pixmap())
        is_selected = bool(option.state & QStyle.StateFlag.State_Selected)
        if is_selected:
            painter.setPen(QPen(self.ACCENT, 2.0))
            painter.setBrush(Qt.BrushStyle.NoBrush)
            painter.drawRect(QRectF(0, 0, self._img_w, self._img_h))
            painter.setPen(QPen(QColor(0, 229, 255, 100), 2))
            painter.drawRect(QRectF(-3, -3, self._img_w + 6, self._img_h + 6))
        self._paint_handle(painter, is_selected)

    def mouseMoveEvent(self, event):
        if self._resizing:
            delta = event.scenePos() - self._resize_start_pos
            self._img_w = max(GRID_STEP, self._snap(self._resize_start_size[0] + delta.x()))
            self._img_h = max(GRID_STEP, self._snap(self._resize_start_size[1] + delta.y()))
            self.prepareGeometryChange()
            self._apply_scaled_pixmap()
            event.accept()
        else:
            super().mouseMoveEvent(event)
