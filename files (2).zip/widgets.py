"""
DrawScript — widgets.py
Reusable Qt widgets: DarkCanvasView and PropertyInspector.
Also exports the _h_rule() factory used by both this module and main.py.
"""

from PyQt6.QtWidgets import (
    QGraphicsView, QGraphicsScene, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QLabel, QSlider, QColorDialog, QFrame, QStackedWidget,
    QSizePolicy,
)
from PyQt6.QtCore import Qt, QRectF
from PyQt6.QtGui import QPainter, QPen, QBrush, QColor, QPixmap

from styles import GRID_STEP
from items import (
    _snap,
    StyledRectItem,
    DraggableTextItem,
    DraggableImageItem,
)


# ---------------------------------------------------------------------------
# Shared UI helper
# ---------------------------------------------------------------------------

def _h_rule() -> QFrame:
    """Return a styled horizontal separator line."""
    line = QFrame()
    line.setFrameShape(QFrame.Shape.HLine)
    return line


# ---------------------------------------------------------------------------
# DarkCanvasView
# ---------------------------------------------------------------------------

class DarkCanvasView(QGraphicsView):
    SCENE_W = 1000
    SCENE_H = 700

    def __init__(self, parent=None):
        super().__init__(parent)
        self.scene = QGraphicsScene(0, 0, self.SCENE_W, self.SCENE_H)
        self.scene.setBackgroundBrush(QBrush(QColor("#ffffff")))
        self.setScene(self.scene)
        self.setRenderHints(
            QPainter.RenderHint.Antialiasing |
            QPainter.RenderHint.TextAntialiasing,
        )
        self.setDragMode(QGraphicsView.DragMode.RubberBandDrag)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)

        self._box_counter   = 0
        self._text_counter  = 0
        self._image_counter = 0
        self._z_counter     = 0

    def drawBackground(self, painter, rect):
        super().drawBackground(painter, rect)
        dim_pen    = QPen(QColor("#f0f0f0"), 1)
        bright_pen = QPen(QColor("#dddddd"), 1)

        x = int(rect.left()) - (int(rect.left()) % GRID_STEP)
        while x <= rect.right():
            painter.setPen(bright_pen if (x // GRID_STEP) % 6 == 0 else dim_pen)
            painter.drawLine(x, int(rect.top()), x, int(rect.bottom()))
            x += GRID_STEP

        y = int(rect.top()) - (int(rect.top()) % GRID_STEP)
        while y <= rect.bottom():
            painter.setPen(bright_pen if (y // GRID_STEP) % 6 == 0 else dim_pen)
            painter.drawLine(int(rect.left()), y, int(rect.right()), y)
            y += GRID_STEP

    def add_box(self):
        offset = (self._box_counter * 24) % 192
        item   = StyledRectItem(60 + offset, 60 + offset)
        item.setZValue(self._z_counter)
        self._z_counter   += 1
        self._box_counter += 1
        self.scene.addItem(item)

    def add_text(self):
        offset = (self._text_counter * 24) % 192
        item   = DraggableTextItem(f"BLOCK_{self._text_counter + 1:02d}", 80 + offset, 80 + offset)
        item.setZValue(self._z_counter)
        self._z_counter    += 1
        self._text_counter += 1
        self.scene.addItem(item)

    def add_image(self, file_path: str):
        offset = (self._image_counter * 24) % 192
        item   = DraggableImageItem(file_path, 72 + offset, 72 + offset)
        item.setZValue(self._z_counter)
        self._z_counter     += 1
        self._image_counter += 1
        self.scene.addItem(item)

    def clear_canvas(self):
        self.scene.clear()
        self._box_counter   = 0
        self._text_counter  = 0
        self._image_counter = 0
        self._z_counter     = 0

    def keyPressEvent(self, event):
        if event.key() == Qt.Key.Key_Space and not event.isAutoRepeat():
            self.setDragMode(QGraphicsView.DragMode.ScrollHandDrag)
            self.viewport().setCursor(Qt.CursorShape.OpenHandCursor)
        else:
            super().keyPressEvent(event)

    def keyReleaseEvent(self, event):
        if event.key() == Qt.Key.Key_Space and not event.isAutoRepeat():
            self.setDragMode(QGraphicsView.DragMode.RubberBandDrag)
            self.viewport().unsetCursor()
        else:
            super().keyReleaseEvent(event)

    def wheelEvent(self, event):
        if event.modifiers() & Qt.KeyboardModifier.ControlModifier:
            factor = 1.15 if event.angleDelta().y() > 0 else 1 / 1.15
            self.scale(factor, factor)
            event.accept()
        else:
            super().wheelEvent(event)

    def mousePressEvent(self, event):
        if self.dragMode() != QGraphicsView.DragMode.ScrollHandDrag:
            hit = self.itemAt(event.pos())
            self.setDragMode(
                QGraphicsView.DragMode.RubberBandDrag if hit is None
                else QGraphicsView.DragMode.NoDrag
            )
        super().mousePressEvent(event)

    def mouseReleaseEvent(self, event):
        super().mouseReleaseEvent(event)
        if self.dragMode() != QGraphicsView.DragMode.ScrollHandDrag:
            self.setDragMode(QGraphicsView.DragMode.RubberBandDrag)


# ---------------------------------------------------------------------------
# PropertyInspector
# ---------------------------------------------------------------------------

class PropertyInspector(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._current_item  = None
        self._current_items = []
        self._scene         = None
        self.status_callback = None

        root = QVBoxLayout(self)
        root.setContentsMargins(12, 10, 12, 8)
        root.setSpacing(6)

        heading = QLabel("[ PROPERTIES ]")
        heading.setObjectName("heading")
        root.addWidget(heading)
        root.addWidget(_h_rule())

        self._stack = QStackedWidget()
        self._stack.addWidget(self._build_empty_page())           # index 0
        self._stack.addWidget(self._build_rect_controls_page())   # index 1
        self._stack.addWidget(self._build_text_controls_page())   # index 2
        self._stack.addWidget(self._build_image_controls_page())  # index 3
        self._stack.addWidget(self._build_alignment_page())       # index 4
        root.addWidget(self._stack)

        self._layer_widget = self._build_layer_section()
        root.addWidget(self._layer_widget)
        self._layer_widget.setVisible(False)

        root.addStretch()
        self._show_empty()

    # ------------------------------------------------------------------
    # Small UI helpers
    # ------------------------------------------------------------------

    def _muted(self, text: str) -> QLabel:
        lbl = QLabel(text)
        lbl.setObjectName("muted")
        return lbl

    def _add_color_btn(self, layout, label_text: str, slot) -> QPushButton:
        layout.addWidget(self._muted(label_text))
        btn = QPushButton("[ CHANGE ]")
        btn.setObjectName("btn_color")
        btn.setCursor(Qt.CursorShape.PointingHandCursor)
        btn.clicked.connect(slot)
        layout.addWidget(btn)
        layout.addWidget(_h_rule())
        return btn

    def _add_slider_row(self, layout, label_text: str, lo: int, hi: int,
                        default: int, slot, fmt=str, tick: int = 0):
        row = QHBoxLayout()
        row.addWidget(self._muted(label_text))
        row.addStretch()
        val_lbl = QLabel(fmt(default))
        val_lbl.setObjectName("muted")
        row.addWidget(val_lbl)
        layout.addLayout(row)
        slider = QSlider(Qt.Orientation.Horizontal)
        slider.setRange(lo, hi)
        slider.setValue(default)
        if tick:
            slider.setTickInterval(tick)
        slider.valueChanged.connect(slot)
        layout.addWidget(slider)
        layout.addWidget(_h_rule())
        return slider, val_lbl

    def _add_info_block(self, layout, header_text: str) -> QLabel:
        layout.addWidget(self._muted(header_text))
        val = QLabel("--")
        val.setObjectName("muted")
        val.setWordWrap(True)
        layout.addWidget(val)
        return val

    # ------------------------------------------------------------------
    # Page builders
    # ------------------------------------------------------------------

    def _build_empty_page(self) -> QWidget:
        page   = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0, 20, 0, 0)
        lbl = QLabel("> SELECT A BLOCK")
        lbl.setObjectName("muted")
        lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(lbl)
        layout.addStretch()
        return page

    def _build_rect_controls_page(self) -> QWidget:
        page   = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0, 6, 0, 0)
        layout.setSpacing(12)
        self.btn_rect_color = self._add_color_btn(layout, "> FILL COLOR", self._on_rect_color_click)
        self.slider_radius, self.lbl_radius_val = self._add_slider_row(
            layout, "> CORNER RAD", 0, 60, 0, self._on_radius_change,
            fmt=lambda v: f"{v}px",
        )
        self.lbl_rect_geometry = self._add_info_block(layout, "> GEOMETRY")
        layout.addStretch()
        return page

    def _build_text_controls_page(self) -> QWidget:
        page   = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0, 6, 0, 0)
        layout.setSpacing(10)
        self.btn_text_color = self._add_color_btn(layout, "> TEXT COLOR", self._on_text_color_click)
        self.slider_size, self.lbl_size_val = self._add_slider_row(
            layout, "> FONT SIZE", 6, 96, 14, self._on_size_change,
            fmt=lambda v: f"{v}pt", tick=6,
        )
        self.slider_thick, self.lbl_thick_val = self._add_slider_row(
            layout, "> THICKNESS", 1, 9, 7, self._on_thick_change,
            fmt=lambda v: str(DraggableTextItem.WEIGHT_CSS.get(v, v * 100)),
        )
        self.lbl_text_geometry = self._add_info_block(layout, "> POSITION")
        layout.addStretch()
        return page

    def _build_image_controls_page(self) -> QWidget:
        page   = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0, 6, 0, 0)
        layout.setSpacing(10)
        layout.addWidget(self._muted("> IMAGE ASSET"))
        layout.addWidget(_h_rule())
        self.lbl_img_path = self._add_info_block(layout, "> FILE PATH")
        layout.addWidget(_h_rule())
        self.lbl_img_geometry = self._add_info_block(layout, "> GEOMETRY")
        layout.addStretch()
        return page

    def _build_alignment_page(self) -> QWidget:
        page   = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0, 6, 0, 0)
        layout.setSpacing(8)

        layout.addWidget(self._muted("> ALIGNMENT"))
        layout.addWidget(_h_rule())

        self._lbl_multi_count = self._muted("> 0 BLOCKS SELECTED")
        layout.addWidget(self._lbl_multi_count)
        layout.addSpacing(4)

        self.btn_align_left     = QPushButton("[ |← ] LEFT")
        self.btn_align_right    = QPushButton("[ →| ] RIGHT")
        self.btn_align_top      = QPushButton("[ ↑ ] TOP")
        self.btn_align_bottom   = QPushButton("[ ↓ ] BOTTOM")
        self.btn_align_center_h = QPushButton("[ ↔ ] CENTER H")

        for btn in (self.btn_align_left, self.btn_align_right,
                    self.btn_align_top,  self.btn_align_bottom,
                    self.btn_align_center_h):
            btn.setObjectName("btn_align")
            btn.setCursor(Qt.CursorShape.PointingHandCursor)

        row1 = QHBoxLayout()
        row1.setSpacing(4)
        row1.addWidget(self.btn_align_left)
        row1.addWidget(self.btn_align_right)
        layout.addLayout(row1)

        row2 = QHBoxLayout()
        row2.setSpacing(4)
        row2.addWidget(self.btn_align_top)
        row2.addWidget(self.btn_align_bottom)
        layout.addLayout(row2)

        layout.addWidget(self.btn_align_center_h)

        self.btn_align_left    .clicked.connect(self._on_align_left)
        self.btn_align_right   .clicked.connect(self._on_align_right)
        self.btn_align_top     .clicked.connect(self._on_align_top)
        self.btn_align_bottom  .clicked.connect(self._on_align_bottom)
        self.btn_align_center_h.clicked.connect(self._on_align_center_h)

        layout.addStretch()
        return page

    # ------------------------------------------------------------------
    # Layer-order section
    # ------------------------------------------------------------------

    def _build_layer_section(self) -> QWidget:
        w      = QWidget()
        layout = QVBoxLayout(w)
        layout.setContentsMargins(0, 4, 0, 0)
        layout.setSpacing(6)
        layout.addWidget(_h_rule())

        hdr = QHBoxLayout()
        hdr.addWidget(self._muted("> LAYER ORDER"))
        hdr.addStretch()
        self.lbl_layer_val = self._muted("Z: 0")
        hdr.addWidget(self.lbl_layer_val)
        layout.addLayout(hdr)

        self.btn_bring_front = QPushButton("[▲] FRONT")
        self.btn_forward     = QPushButton("[↑] FORWARD")
        self.btn_backward    = QPushButton("[↓] BACKWARD")
        self.btn_send_back   = QPushButton("[▼] BACK")

        for btn in (self.btn_bring_front, self.btn_forward,
                    self.btn_backward,    self.btn_send_back):
            btn.setCursor(Qt.CursorShape.PointingHandCursor)

        row1 = QHBoxLayout()
        row1.setSpacing(4)
        row1.addWidget(self.btn_bring_front)
        row1.addWidget(self.btn_forward)
        layout.addLayout(row1)

        row2 = QHBoxLayout()
        row2.setSpacing(4)
        row2.addWidget(self.btn_backward)
        row2.addWidget(self.btn_send_back)
        layout.addLayout(row2)

        self.btn_bring_front.clicked.connect(self._on_bring_front)
        self.btn_forward    .clicked.connect(self._on_forward)
        self.btn_backward   .clicked.connect(self._on_backward)
        self.btn_send_back  .clicked.connect(self._on_send_back)
        return w

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def load_item(self, item, scene=None):
        self._current_item = item
        self._scene        = scene
        if isinstance(item, StyledRectItem):
            self._refresh_rect_controls()
            self._stack.setCurrentIndex(1)
        elif isinstance(item, DraggableTextItem):
            self._refresh_text_controls()
            self._stack.setCurrentIndex(2)
        elif isinstance(item, DraggableImageItem):
            self._refresh_image_controls()
            self._stack.setCurrentIndex(3)
        self._update_layer_label()
        self._layer_widget.setVisible(True)

    def load_multi_select(self, items: list, scene=None):
        self._current_item  = None
        self._current_items = list(items)
        self._scene         = scene
        self._lbl_multi_count.setText(f"> {len(items)} BLOCKS SELECTED")
        self._stack.setCurrentIndex(4)
        self._layer_widget.setVisible(False)

    def clear(self):
        self._current_item  = None
        self._current_items = []
        self._scene         = None
        self._layer_widget.setVisible(False)
        self._show_empty()

    # ------------------------------------------------------------------
    # Private refresh helpers
    # ------------------------------------------------------------------

    def _show_empty(self):
        self._stack.setCurrentIndex(0)

    def _update_layer_label(self):
        if self._current_item:
            self.lbl_layer_val.setText(f"Z: {int(self._current_item.zValue())}")

    def _refresh_rect_controls(self):
        item = self._current_item
        self._apply_swatch(self.btn_rect_color, item.fill_color())
        self.slider_radius.blockSignals(True)
        self.slider_radius.setValue(int(item.border_radius()))
        self.lbl_radius_val.setText(f"{int(item.border_radius())}px")
        self.slider_radius.blockSignals(False)
        pos  = item.pos()
        rect = item.rect()
        self.lbl_rect_geometry.setText(
            f"X:{pos.x():.0f} Y:{pos.y():.0f}  W:{rect.width():.0f} H:{rect.height():.0f}"
        )

    def _refresh_text_controls(self):
        item = self._current_item
        self._apply_swatch(self.btn_text_color, item.text_color())
        self.slider_size.blockSignals(True)
        self.slider_size.setValue(item.font_size())
        self.lbl_size_val.setText(f"{item.font_size()}pt")
        self.slider_size.blockSignals(False)
        self.slider_thick.blockSignals(True)
        self.slider_thick.setValue(item.thickness())
        self.lbl_thick_val.setText(str(item.thickness_css()))
        self.slider_thick.blockSignals(False)
        pos = item.pos()
        self.lbl_text_geometry.setText(f"X:{pos.x():.0f} Y:{pos.y():.0f}")

    def _refresh_image_controls(self):
        item      = self._current_item
        full_path = item.file_path()
        display   = full_path if len(full_path) <= 42 else f"...{full_path[-40:]}"
        self.lbl_img_path.setText(display)
        self.lbl_img_path.setToolTip(full_path)
        pos = item.pos()
        self.lbl_img_geometry.setText(
            f"X:{pos.x():.0f} Y:{pos.y():.0f}  W:{item.img_width():.0f} H:{item.img_height():.0f}"
        )

    def _apply_swatch(self, btn: QPushButton, color: QColor):
        luminance = 0.299 * color.red() + 0.587 * color.green() + 0.114 * color.blue()
        text_col  = "#00E5FF" if luminance < 140 else "#000000"
        btn.setStyleSheet(
            f"QPushButton#btn_color {{"
            f"  background-color: {color.name()}; color: {text_col};"
            f"  border-top: 2px solid #6a6a6a; border-left: 2px solid #6a6a6a;"
            f"  border-bottom: 2px solid #1a1a1a; border-right: 2px solid #1a1a1a;"
            f"  border-radius: 0px;"
            f"}}"
        )
        btn.setText(color.name().upper())

    # ------------------------------------------------------------------
    # Slot handlers
    # ------------------------------------------------------------------

    def _on_rect_color_click(self):
        if not self._current_item:
            return
        color = QColorDialog.getColor(
            self._current_item.fill_color(), self, "CHOOSE FILL COLOR",
            QColorDialog.ColorDialogOption.ShowAlphaChannel,
        )
        if color.isValid():
            self._current_item.set_fill_color(color)
            self._apply_swatch(self.btn_rect_color, color)

    def _on_text_color_click(self):
        if not self._current_item:
            return
        color = QColorDialog.getColor(
            self._current_item.text_color(), self, "CHOOSE TEXT COLOR",
            QColorDialog.ColorDialogOption.ShowAlphaChannel,
        )
        if color.isValid():
            self._current_item.set_text_color(color)
            self._apply_swatch(self.btn_text_color, color)

    def _on_radius_change(self, value: int):
        self.lbl_radius_val.setText(f"{value}px")
        if self._current_item:
            self._current_item.set_border_radius(value)

    def _on_size_change(self, value: int):
        self.lbl_size_val.setText(f"{value}pt")
        if self._current_item:
            self._current_item.set_font_size(value)

    def _on_thick_change(self, value: int):
        self.lbl_thick_val.setText(str(DraggableTextItem.WEIGHT_CSS.get(value, value * 100)))
        if self._current_item:
            self._current_item.set_thickness(value)

    # ------------------------------------------------------------------
    # Alignment slot handlers
    # ------------------------------------------------------------------

    @staticmethod
    def _item_size(item) -> tuple:
        br = item.boundingRect()
        return br.width(), br.height()

    def _emit_status(self, msg: str):
        if callable(self.status_callback):
            self.status_callback(msg)

    def _on_align_left(self):
        items = self._current_items
        if len(items) < 2:
            return
        target = _snap(min(it.x() for it in items))
        for it in items:
            it.setX(target)
        self._emit_status("LAYOUT SYNCHRONIZED — LEFT EDGE LOCKED.")

    def _on_align_right(self):
        items = self._current_items
        if len(items) < 2:
            return
        target = _snap(max(it.x() + self._item_size(it)[0] for it in items))
        for it in items:
            it.setX(_snap(target - self._item_size(it)[0]))
        self._emit_status("BLOCKS ALIGNED TO GRID — RIGHT EDGE FLUSH.")

    def _on_align_top(self):
        items = self._current_items
        if len(items) < 2:
            return
        target = _snap(min(it.y() for it in items))
        for it in items:
            it.setY(target)
        self._emit_status("TOP RAIL ESTABLISHED. GRID INTEGRITY CONFIRMED.")

    def _on_align_bottom(self):
        items = self._current_items
        if len(items) < 2:
            return
        target = _snap(max(it.y() + self._item_size(it)[1] for it in items))
        for it in items:
            it.setY(_snap(target - self._item_size(it)[1]))
        self._emit_status("BLOCKS ALIGNED TO GRID — BOTTOM BASELINE SET.")

    def _on_align_center_h(self):
        items = self._current_items
        if len(items) < 2:
            return
        min_x  = min(it.x() for it in items)
        max_x  = max(it.x() + self._item_size(it)[0] for it in items)
        center = (min_x + max_x) / 2.0
        for it in items:
            it.setX(_snap(center - self._item_size(it)[0] / 2.0))
        self._emit_status("HORIZONTAL CENTER MASS COMPUTED. BLOCKS REALIGNED.")

    # ------------------------------------------------------------------
    # Layer-order slot handlers
    # ------------------------------------------------------------------

    def _on_bring_front(self):
        if not self._current_item:
            return
        peers = [it for it in (self._scene.items() if self._scene else [])
                 if it is not self._current_item]
        self._current_item.setZValue(max((it.zValue() for it in peers), default=0) + 1)
        self._update_layer_label()

    def _on_send_back(self):
        if not self._current_item:
            return
        peers = [it for it in (self._scene.items() if self._scene else [])
                 if it is not self._current_item]
        self._current_item.setZValue(min((it.zValue() for it in peers), default=0) - 1)
        self._update_layer_label()

    def _on_forward(self):
        if not self._current_item:
            return
        self._current_item.setZValue(self._current_item.zValue() + 1)
        self._update_layer_label()

    def _on_backward(self):
        if not self._current_item:
            return
        self._current_item.setZValue(self._current_item.zValue() - 1)
        self._update_layer_label()
